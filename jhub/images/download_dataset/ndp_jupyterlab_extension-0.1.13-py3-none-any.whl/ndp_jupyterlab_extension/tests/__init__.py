"""Python unit tests for ndp_jupyterlab_extension."""
