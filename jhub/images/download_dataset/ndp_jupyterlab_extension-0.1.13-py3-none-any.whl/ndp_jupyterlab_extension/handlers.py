import json

from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import tornado

import os
import requests
import zipfile
import subprocess

from keycloak import KeycloakOpenID

# Use an environment variable for the dynamic parameter
workspace_api_url = os.getenv('WORKSPACE_API_URL', 'https://fake-api.nrp-nautilus.io/')
access_token = os.getenv('ACCESS_TOKEN', '')

def install_requirements(path):
    # install requirements.txt packages

    # Construct the full file path for requirements.txt
    requirements_path = os.path.join(path, 'requirements.txt')

    # Check if requirements.txt exists
    if os.path.isfile(requirements_path):
        print(f"Found requirements.txt at {requirements_path}. Installing libraries...")
        # Run pip install command
        result = subprocess.run(['pip', 'install', '-r', requirements_path], capture_output=True, text=True)
        if result.returncode == 0:
            print("Libraries installed successfully.")
        else:
            print("An error occurred while installing libraries.")
            print(result.stdout)
            print(result.stderr)
    else:
        print("No requirements.txt found in the directory.")


def unzip(folder_path):
    # unzip
    # Loop through all files in the directory
    found_zip = False
    for filename in os.listdir(folder_path):
        if filename.endswith('.zip'):
            found_zip = True
            # Construct the full file path
            file_path = os.path.join(folder_path, filename)

            # Unzip the file
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                # Loop through each file in the zip archive
                for member in zip_ref.namelist():
                    # Construct the full path for the extracted file
                    member_path = os.path.join(folder_path, member)

                    # Check if the file already exists
                    if os.path.exists(member_path):
                        print(f"File {member_path} already exists. Skipping extraction.")
                    else:
                        # Extract the file
                        zip_ref.extract(member, folder_path)
                        print(f"Extracted {member_path} successfully.")


def download(path):
    # make call to Workspace API to get a list of datasets in the shopping cart
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    # response = requests.get(workspace_api_url, headers=headers)
    # # Checking the response
    # if response.status_code == 200:
    #     print("Request was successful.")
    #     dataset_ids = response.json()['datasets']  # Assuming the response is JSON
    #     print(dataset_ids)
    # else:
    #     print(f"Request failed with status code {response.status_code}.")
    #     print(response.text)
    #     dataset_ids = []

    dataset_ids = ['jupyterhub-testing-dataset']

    for dataset_id in dataset_ids:
        folder_path = f'./{path}/' + dataset_id

        # Ensure the folder exists
        os.makedirs(folder_path, exist_ok=True)

        api_url = 'https://ndp-test.sdsc.edu/catalog/api/3/action/'
        endpoint = 'package_show'
        resources = requests.get(api_url + endpoint, params={"id": dataset_id}).json()['result']['resources']
        file_urls = [x['url'] for x in resources]

        # download
        for url in file_urls:
            response = requests.get(url)

            # Check if the request was successful
            if response.status_code == 200:
                # Extracting the filename from the URL
                filename = url.split('/')[-1]

                file_path = os.path.join(folder_path, filename)

                # Saving the file
                with open(file_path, 'wb') as file:
                    file.write(response.content)
                print(f"{filename} downloaded successfully.")
            else:
                print(f"Failed to download {url}")


class DownloadRouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):

        # self.finish(json.dumps({
        #     "data": "This is /ndp-jupyterlab-extension/get-example endpoint!"
        # datasets = requests.get('https://fake-api.nrp-nautilus.io/').json()
        data = self.get_json_body()
        print(data)
        datasets = ['jupyterhub-testing-dataset']
        download(data['path'])
        self.finish(json.dumps({"datasets for download": datasets}))

class UnZIPRouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):

        # self.finish(json.dumps({
        #     "data": "This is /ndp-jupyterlab-extension/get-example endpoint!"
        # datasets = requests.get('https://fake-api.nrp-nautilus.io/').json()
        data = self.get_json_body()
        print(data)
        unzip(data['path'])
        self.finish(json.dumps({"message": "archive unzipped"}))

class InstallRequirementsRouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):
        data = self.get_json_body()
        print(data)
        install_requirements(data['path'])
        self.finish(json.dumps({"message": "requirements installed"}))


class GetWorkspacesDataRouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self):
        # Get token from Keycloak
        keycloak_openid = KeycloakOpenID(server_url="https://idp-test.nationaldataplatform.org/",
                                         client_id="python_test",
                                         realm_name="NDP",
                                         client_secret_key="TMEITmuyXyzPMdu7HHAKKHQesCdIZxoj")

        def get_tokens():
            tokens = keycloak_openid.refresh_token(os.environ['REFRESH_TOKEN'])
            # print(tokens)
            access_token = tokens['access_token']
            refresh_token = tokens['refresh_token']
            os.environ['REFRESH_TOKEN'] = refresh_token
            return access_token

        access_token = get_tokens()

        # Get data
        url = "https://ndp-test.sdsc.edu/workspaces-api/workspace/read_workspaces_by_user"

        payload = {}
        headers = {
            'Authorization': f'Bearer {access_token}'
        }

        response = requests.request("GET", url, headers=headers, data=payload)

        print(json.dumps(response.json(), indent=4))

        workspaces = [x["workspace_name"] for x in response.json()]

        self.finish(json.dumps({"workspaces": workspaces}))

def setup_handlers(web_app):
    host_pattern = ".*$"

    base_url = web_app.settings["base_url"]
    route_pattern_download = url_path_join(base_url, "ndp-jupyterlab-extension", "download_datasets")
    route_pattern_unzip = url_path_join(base_url, "ndp-jupyterlab-extension", "unzip")
    route_pattern_install = url_path_join(base_url, "ndp-jupyterlab-extension", "install_requirements")
    route_pattern_get_workspaces_data = url_path_join(base_url, "ndp-jupyterlab-extension", "get_workspaces_data")
    handlers = [
        (route_pattern_download, DownloadRouteHandler),
        (route_pattern_unzip, UnZIPRouteHandler),
        (route_pattern_install, InstallRequirementsRouteHandler),
        (route_pattern_get_workspaces_data, GetWorkspacesDataRouteHandler),
    ]
    web_app.add_handlers(host_pattern, handlers)
