"use strict";
(self["webpackChunkndp_jupyterlab_extension"] = self["webpackChunkndp_jupyterlab_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
// import { requestAPI } from './handler';

/**
 * Initialization data for the ndp-jupyterlab-extension extension.
 */
const extension = {
    id: 'ndp-jupyterlab-extension:plugin',
    description: 'A JupyterLab extension for National Data Platform.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette],
    activate: (app, palette) => {
        const { commands } = app;
        // Add a command
        const command = 'jlab-examples:main-menu';
        commands.addCommand(command, {
            label: 'Execute jlab-examples:main-menu Command',
            caption: 'Execute jlab-examples:main-menu Command',
            execute: (args) => {
                console.log(`jlab-examples:main-menu has been called ${args['origin']}.`);
                window.alert(`jlab-examples:main-menu has been called ${args['origin']}.`);
            }
        });
        // Add the command to the command palette
        const category = 'Extension Examples';
        palette.addItem({
            command,
            category,
            args: { origin: 'from the palette' }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
// const plugin: JupyterFrontEndPlugin<void> = {
//   id: 'ndp-jupyterlab-extension:plugin',
//   description: 'A JupyterLab extension for National Data Platform.',
//   autoStart: true,
//   requires: [ICommandPalette],
//   activate: (app: JupyterFrontEnd) => {
//     console.log('JupyterLab extension ndp-jupyterlab-extension is activated!');
//     console.log('Making request to JupyterLab API');
//     requestAPI<any>('get-example')
//       .then(data => {
//         console.log(data);
//         console.log('Request is made');
//       })
//       .catch(reason => {
//         console.error(
//           `The ndp_jupyterlab_extension server extension appears to be missing.\n${reason}`
//         );
//       });
//   }
// };
// export default plugin;


/***/ })

}]);
//# sourceMappingURL=lib_index_js.dc6fdd9fc54f38897cf8.js.map