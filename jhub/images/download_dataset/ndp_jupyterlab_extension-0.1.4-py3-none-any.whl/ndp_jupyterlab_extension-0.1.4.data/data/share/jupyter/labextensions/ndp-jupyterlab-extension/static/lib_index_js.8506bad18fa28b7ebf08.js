"use strict";
(self["webpackChunkndp_jupyterlab_extension"] = self["webpackChunkndp_jupyterlab_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);

// import { requestAPI } from './handler';

/**
 * Initialization data for the main menu example.
 */
// const extension: JupyterFrontEndPlugin<void> = {
//   id: '@jupyterlab-examples/main-menu:plugin',
//   description: 'Minimal JupyterLab example adding a menu.',
//   autoStart: true,
//   requires: [ICommandPalette],
//   activate: (app: JupyterFrontEnd, palette: ICommandPalette) => {
//     const { commands } = app;
//
//     // Add a command
//     const command = 'jlab-examples:main-menu';
//     commands.addCommand(command, {
//       label: 'Download datasets from NDP',
//       caption: 'Download datasets from NDP',
//       execute: (args: any) => {
//         console.log(
//           'JupyterLab extension ndp-jupyterlab-extension is activated!'
//         );
//         window.alert('Datasets download invoked');
//         console.log('Making request to JupyterLab API');
//         requestAPI<any>('get-example')
//           .then(data => {
//             console.log(data);
//             console.log('Request is made');
//           })
//           .catch(reason => {
//             console.error(
//               `The ndp_jupyterlab_extension server extension appears to be missing.\n${reason}`
//             );
//           });
//         window.alert('Datasets successfully downloaded');
//       }
//     });
//
//     // Add the command to the command palette
//     const category = 'Extension Examples';
//     palette.addItem({
//       command,
//       category,
//       args: { origin: 'from the palette' }
//     });
//   }
// };
//
// export default extension;
// import {
//   JupyterFrontEnd,
//   JupyterFrontEndPlugin
// } from '@jupyterlab/application';
//
// import { ICommandPalette } from '@jupyterlab/apputils';
//
// import { Message } from '@lumino/messaging';
//
// import { Widget } from '@lumino/widgets';
/**
 * Activate the widgets example extension.
 */
const extension = {
    id: '@jupyterlab-examples/main-menu:plugin',
    description: 'Minimal JupyterLab example adding a menu.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette],
    activate: (app, palette) => {
        const { commands, shell } = app;
        const command = 'widgets:open-tab';
        commands.addCommand(command, {
            label: 'Open a Tab Widget',
            caption: 'Open the Widgets Example Tab',
            execute: () => {
                const widget = new ExampleWidget();
                shell.add(widget, 'left');
            }
        });
        palette.addItem({ command, category: 'Extension Examples' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
class ExampleWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor() {
        super();
        this.addClass('jp-example-view');
        this.id = 'simple-widget-example';
        this.title.label = 'NDP';
        this.title.closable = true;
    }
    /**
     * Event generic callback on an object as defined in the specification
     *
     * See https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#the_event_listener_callback
     */
    handleEvent(event) {
        switch (event.type) {
            case 'pointerenter':
                this._onMouseEnter(event);
                break;
            case 'pointerleave':
                this._onMouseLeave(event);
                break;
        }
    }
    /**
     * Callback when the widget is added to the DOM
     *
     * This is the recommended place to listen for DOM events
     */
    onAfterAttach(msg) {
        // The first two events are not linked to a specific callback but
        // to this object. In that case, the object method `handleEvent`
        // is the function called when an event occurs.
        this.node.addEventListener('pointerenter', this);
        this.node.addEventListener('pointerleave', this);
        // This event will call a specific function when occuring
        this.node.addEventListener('click', this._onEventClick.bind(this));
    }
    /**
     * Callback when the widget is removed from the DOM
     *
     * This is the recommended place to stop listening for DOM events
     */
    onBeforeDetach(msg) {
        this.node.removeEventListener('pointerenter', this);
        this.node.removeEventListener('pointerleave', this);
        this.node.removeEventListener('click', this._onEventClick.bind(this));
    }
    /**
     * Callback on click on the widget
     */
    _onEventClick(event) {
        window.alert('You clicked on the widget');
    }
    /**
     * Callback on pointer entering the widget
     */
    _onMouseEnter(event) {
        this.node.style['backgroundColor'] = 'orange';
    }
    /**
     * Callback on pointer leaving the widget
     */
    _onMouseLeave(event) {
        this.node.style['backgroundColor'] = 'aliceblue';
    }
}


/***/ })

}]);
//# sourceMappingURL=lib_index_js.8506bad18fa28b7ebf08.js.map