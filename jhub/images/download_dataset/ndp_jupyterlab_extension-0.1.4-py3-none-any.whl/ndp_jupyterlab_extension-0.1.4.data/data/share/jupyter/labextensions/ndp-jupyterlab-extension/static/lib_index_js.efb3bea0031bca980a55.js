"use strict";
(self["webpackChunkndp_jupyterlab_extension"] = self["webpackChunkndp_jupyterlab_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ndp-jupyterlab-extension', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icon_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icon.svg */ "./style/icon.svg");




// Define the icon
 // Path to your icon SVG file
const exampleIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'my-extension:example-icon',
    svgstr: _style_icon_svg__WEBPACK_IMPORTED_MODULE_3__
});
/**
 * Initialization data for the main menu example.
 */
const extension = {
    id: '@jupyterlab-examples/main-menu:plugin',
    description: 'Minimal JupyterLab example adding a menu.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette],
    activate: (app, palette) => {
        const { commands, shell } = app;
        const command = 'widgets:open-tab';
        const widget = new ExampleWidget();
        shell.add(widget, 'left');
        commands.addCommand(command, {
            label: 'Open a Tab Widget',
            caption: 'Open the Widgets Example Tab',
            icon: exampleIcon,
            execute: () => {
                const widget = new ExampleWidget();
                shell.add(widget, 'left');
            }
        });
        // palette.addItem({ command, category: 'Extension Examples' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
class ExampleWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor() {
        super();
        this.addClass('jp-example-view');
        this.id = 'simple-widget-example';
        this.title.label = 'NDP';
        this.title.closable = true;
        this.title.icon = exampleIcon; // Set the icon for the widget
        // Create a button element
        const button = document.createElement('button');
        button.textContent = 'Download NDP Datasets';
        button.className = 'my-button';
        button.addEventListener('click', this._onButtonClick.bind(this));
        // Create a div to center the button
        const container = document.createElement('div');
        container.className = 'button-container';
        container.appendChild(button);
        // Append the container to the widget's DOM node
        this.node.appendChild(container);
    }
    /**
     * Callback on click on the widget
     */
    _onButtonClick(event) {
        console.log('JupyterLab extension ndp-jupyterlab-extension is activated!');
        window.alert('Datasets download invoked');
        console.log('Making request to JupyterLab API');
        (0,_handler__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('get-example')
            .then(data => {
            console.log(data);
            console.log('Request is made');
        })
            .catch(reason => {
            console.error(`The ndp_jupyterlab_extension server extension appears to be missing.\n${reason}`);
        });
        window.alert('Datasets successfully downloaded');
    }
}
// Add CSS styles to center the button
const style = document.createElement('style');
style.textContent = `
  .button-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
  }
  .my-button {
    padding: 10px 20px;
    font-size: 16px;
  }
`;
document.head.appendChild(style);


/***/ }),

/***/ "./style/icon.svg":
/*!************************!*\
  !*** ./style/icon.svg ***!
  \************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" standalone=\"no\"?>\n<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20010904//EN\"\n \"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n<svg version=\"1.0\" xmlns=\"http://www.w3.org/2000/svg\"\n width=\"147.000000pt\" height=\"39.000000pt\" viewBox=\"0 0 147.000000 39.000000\"\n preserveAspectRatio=\"xMidYMid meet\">\n\n<g transform=\"translate(0.000000,39.000000) scale(0.100000,-0.100000)\"\nfill=\"#000000\" stroke=\"none\">\n<path d=\"M12 315 c1 -54 2 -59 5 -22 2 26 8 47 14 47 5 0 9 -3 9 -7 0 -5 16\n-26 35 -48 l34 -40 -1 70 c-1 59 -2 62 -5 20 l-4 -50 -44 50 -44 50 1 -70z\"/>\n<path d=\"M163 318 c-23 -61 -25 -88 -3 -49 15 28 66 29 75 1 3 -11 10 -20 16\n-20 7 0 1 21 -38 118 -11 27 -29 9 -50 -50z m52 5 c5 -20 3 -23 -18 -23 -24 0\n-25 2 -14 30 12 31 20 29 32 -7z\"/>\n<path d=\"M278 370 c19 -8 22 -17 24 -67 l1 -58 6 59 c5 47 10 61 26 67 14 5 4\n8 -30 8 -40 0 -45 -2 -27 -9z\"/>\n<path d=\"M380 315 c0 -37 4 -65 10 -65 6 0 10 28 10 65 0 37 -4 65 -10 65 -6\n0 -10 -28 -10 -65z\"/>\n<path d=\"M447 362 c-23 -25 -21 -68 3 -92 58 -58 142 20 94 88 -19 28 -74 30\n-97 4z m77 -8 c24 -23 20 -61 -8 -79 -36 -24 -66 -5 -66 40 0 49 42 71 74 39z\"/>\n<path d=\"M590 315 c0 -41 4 -65 11 -65 7 0 10 17 7 45 -2 25 -1 45 3 45 3 0\n20 -20 39 -45 19 -25 37 -45 42 -45 4 0 8 29 8 65 0 74 -17 89 -22 18 l-3 -47\n-35 47 c-19 25 -38 47 -42 47 -5 0 -8 -29 -8 -65z\"/>\n<path d=\"M761 358 c-5 -13 -16 -40 -25 -62 -19 -45 -19 -46 -7 -46 5 0 13 9\n16 20 4 14 15 20 35 20 20 0 31 -6 35 -20 3 -11 11 -20 16 -20 12 0 12 -2 -15\n65 -27 66 -42 78 -55 43z m38 -45 c1 -7 -8 -13 -19 -13 -23 0 -25 12 -8 43 11\n21 11 21 19 2 4 -11 8 -26 8 -32z\"/>\n<path d=\"M860 315 l0 -65 41 0 c24 0 38 4 34 10 -3 6 -17 10 -31 10 -23 0 -24\n3 -24 55 0 30 -4 55 -10 55 -6 0 -10 -28 -10 -65z\"/>\n<path d=\"M1000 315 l0 -65 34 0 c44 0 79 28 79 63 0 41 -29 67 -75 67 l-38 0\n0 -65z m80 35 c23 -23 24 -33 10 -61 -7 -12 -21 -19 -40 -19 -29 0 -30 1 -30\n50 0 43 3 50 20 50 11 0 29 -9 40 -20z\"/>\n<path d=\"M1148 315 c-23 -60 -22 -90 2 -45 6 12 21 20 35 20 14 0 29 -8 35\n-20 6 -11 15 -20 19 -20 5 0 -2 29 -17 65 -14 36 -30 65 -37 65 -6 0 -23 -29\n-37 -65z m57 8 c5 -20 3 -23 -19 -23 -24 0 -24 2 -14 31 11 32 21 29 33 -8z\"/>\n<path d=\"M1268 370 c19 -8 22 -17 24 -67 l1 -58 6 60 c5 52 9 60 31 66 17 5 8\n7 -30 7 -42 1 -50 -1 -32 -8z\"/>\n<path d=\"M1368 315 c-15 -36 -22 -65 -17 -65 4 0 13 9 19 20 14 27 56 26 70\n-1 7 -11 14 -18 17 -15 8 8 -41 126 -53 126 -6 0 -22 -29 -36 -65z m40 -13\nc-28 -5 -31 1 -16 33 l12 28 12 -29 c11 -26 10 -29 -8 -32z\"/>\n<path d=\"M10 111 c0 -61 4 -101 10 -101 6 0 10 15 10 34 0 31 3 34 36 39 44 7\n74 32 74 62 0 39 -23 57 -78 63 l-52 5 0 -102z m100 60 c5 -11 10 -24 10 -30\n0 -19 -32 -41 -61 -41 -28 0 -29 2 -29 45 0 45 0 45 35 45 24 0 37 -6 45 -19z\"/>\n<path d=\"M180 110 l0 -100 58 2 57 1 -45 6 -45 6 -3 93 c-4 125 -22 119 -22\n-8z\"/>\n<path d=\"M353 127 c-18 -45 -35 -90 -39 -99 -3 -10 -1 -18 5 -18 6 0 13 11 17\n25 6 23 11 25 60 25 49 0 54 -2 60 -25 5 -22 24 -36 24 -18 0 22 -74 193 -84\n193 -6 0 -25 -37 -43 -83z m68 -2 l17 -45 -39 0 c-21 0 -39 3 -39 7 0 17 33\n93 39 88 3 -3 13 -26 22 -50z\"/>\n<path d=\"M480 200 c0 -5 16 -10 35 -10 l35 0 0 -90 c0 -53 4 -90 10 -90 6 0\n10 37 10 90 l0 90 35 0 c19 0 35 5 35 10 0 6 -33 10 -80 10 -47 0 -80 -4 -80\n-10z\"/>\n<path d=\"M670 110 c0 -99 16 -141 22 -57 3 42 3 42 48 48 l45 5 -45 5 c-44 4\n-45 5 -48 42 l-3 37 50 0 c28 0 51 5 51 10 0 6 -27 10 -60 10 l-60 0 0 -100z\"/>\n<path d=\"M870 197 c-54 -27 -66 -106 -24 -156 21 -25 33 -31 66 -31 52 0 77\n14 94 55 19 45 8 90 -28 120 -32 27 -70 32 -108 12z m101 -28 c30 -30 24 -105\n-12 -132 -77 -57 -159 62 -92 135 22 25 78 23 104 -3z\"/>\n<path d=\"M1060 110 c0 -60 4 -100 10 -100 6 0 10 18 10 40 0 36 3 40 25 40 14\n0 25 -4 25 -8 0 -13 58 -77 64 -71 3 3 -8 24 -24 46 -29 40 -30 42 -10 48 21\n7 36 45 26 70 -7 20 -48 35 -92 35 l-34 0 0 -100z m104 58 c17 -27 -5 -52 -48\n-56 l-36 -3 0 41 0 41 36 -3 c22 -2 42 -10 48 -20z\"/>\n<path d=\"M1240 110 c0 -60 4 -100 10 -100 6 0 10 32 10 75 0 41 3 75 8 75 4 0\n22 -27 40 -60 18 -33 36 -60 41 -60 5 0 23 28 42 62 l34 63 3 -77 c4 -114 22\n-96 22 22 0 55 -4 100 -9 100 -5 0 -29 -34 -52 -76 l-42 -76 -40 76 c-55 106\n-67 101 -67 -24z\"/>\n</g>\n</svg>\n";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.efb3bea0031bca980a55.js.map