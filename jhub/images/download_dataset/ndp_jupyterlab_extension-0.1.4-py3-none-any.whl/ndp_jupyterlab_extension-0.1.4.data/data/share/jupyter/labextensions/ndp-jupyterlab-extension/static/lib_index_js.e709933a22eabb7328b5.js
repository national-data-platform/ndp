"use strict";
(self["webpackChunkndp_jupyterlab_extension"] = self["webpackChunkndp_jupyterlab_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ndp-jupyterlab-extension', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);



// import { Message } from '@lumino/messaging';
/**
 * Initialization data for the main menu example.
 */
const extension = {
    id: '@jupyterlab-examples/main-menu:plugin',
    description: 'Minimal JupyterLab example adding a menu.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette],
    activate: (app, palette) => {
        const { commands, shell } = app;
        const command = 'widgets:open-tab';
        const widget = new ExampleWidget();
        shell.add(widget, 'left');
        commands.addCommand(command, {
            label: 'Open a Tab Widget',
            caption: 'Open the Widgets Example Tab',
            execute: () => {
                const widget = new ExampleWidget();
                shell.add(widget, 'left');
            }
        });
        // palette.addItem({ command, category: 'Extension Examples' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
class ExampleWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor() {
        super();
        this.addClass('jp-example-view');
        this.id = 'simple-widget-example';
        this.title.label = 'NDP';
        this.title.closable = true;
        // Create a button element
        const button = document.createElement('button');
        button.textContent = 'Click me!';
        button.className = 'my-button';
        button.addEventListener('click', this._onButtonClick.bind(this));
        // Append the button to the widget's DOM node
        this.node.appendChild(button);
    }
    /**
     * Event generic callback on an object as defined in the specification
     *
     * See https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#the_event_listener_callback
     */
    // handleEvent(event: Event): void {
    //   switch (event.type) {
    //     case 'pointerenter':
    //       this._onMouseEnter(event);
    //       break;
    //     case 'pointerleave':
    //       this._onMouseLeave(event);
    //       break;
    //   }
    // }
    /**
     * Callback when the widget is added to the DOM
     *
     * This is the recommended place to listen for DOM events
     */
    // protected onAfterAttach(msg: Message): void {
    //   // The first two events are not linked to a specific callback but
    //   // to this object. In that case, the object method `handleEvent`
    //   // is the function called when an event occurs.
    //   // this.node.addEventListener('pointerenter', this);
    //   // this.node.addEventListener('pointerleave', this);
    //   // This event will call a specific function when occuring
    //   this.node.addEventListener('click', this._onEventClick.bind(this));
    // }
    /**
     * Callback when the widget is removed from the DOM
     *
     * This is the recommended place to stop listening for DOM events
     */
    // protected onBeforeDetach(msg: Message): void {
    //   // this.node.removeEventListener('pointerenter', this);
    //   // this.node.removeEventListener('pointerleave', this);
    //   this.node.removeEventListener('click', this._onEventClick.bind(this));
    // }
    /**
     * Callback on click on the widget
     */
    _onButtonClick(event) {
        console.log('JupyterLab extension ndp-jupyterlab-extension is activated!');
        window.alert('Datasets download invoked');
        console.log('Making request to JupyterLab API');
        (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('get-example')
            .then(data => {
            console.log(data);
            console.log('Request is made');
        })
            .catch(reason => {
            console.error(`The ndp_jupyterlab_extension server extension appears to be missing.\n${reason}`);
        });
        window.alert('Datasets successfully downloaded');
    }
}


/***/ })

}]);
//# sourceMappingURL=lib_index_js.e709933a22eabb7328b5.js.map