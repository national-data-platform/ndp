"use strict";
(self["webpackChunkndp_jupyterlab_extension"] = self["webpackChunkndp_jupyterlab_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ndp-jupyterlab-extension', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_ndp_logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/ndp_logo.png */ "./style/ndp_logo.png");





// Define the icon
 // Path to your PNG file
/**
 * Initialization data for the main menu example.
 */
const extension = {
    id: '@jupyterlab-examples/main-menu:plugin',
    description: 'Minimal JupyterLab example adding a menu.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IFileBrowserFactory, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IDefaultFileBrowser],
    activate: (app, palette, fileBrowserFactory, defaultBrowser) => {
        const { commands, shell } = app;
        const command = 'widgets:open-tab';
        const widget = new ExampleWidget(fileBrowserFactory, defaultBrowser);
        shell.add(widget, 'left');
        commands.addCommand(command, {
            label: 'Open a Tab Widget',
            caption: 'Open the Widgets Example Tab',
            execute: () => {
                const widget = new ExampleWidget(fileBrowserFactory, defaultBrowser);
                shell.add(widget, 'left');
            }
        });
        // palette.addItem({ command, category: 'Extension Examples' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);
class ExampleWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor(fileBrowserFactory, defaultBrowser) {
        super();
        this.fileBrowser = _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_2__.IDefaultFileBrowser;
        this.addClass('jp-example-view');
        this.id = 'simple-widget-example';
        this.title.label = 'NDP';
        this.title.closable = true;
        // Create an image element for the icon
        const iconImg = document.createElement('img');
        iconImg.src = _style_ndp_logo_png__WEBPACK_IMPORTED_MODULE_3__;
        iconImg.className = 'my-widget-icon';
        // Create a button element
        const button = document.createElement('button');
        button.textContent = 'Download NDP Datasets';
        button.className = 'my-button';
        button.addEventListener('click', this._onButtonClick.bind(this));
        // Create a spinner element
        this.spinner = document.createElement('div');
        this.spinner.className = 'spinner';
        this.spinner.style.display = 'none'; // Hide spinner initially
        // Create a div to center the button and spinner
        const container = document.createElement('div');
        container.className = 'button-container';
        container.appendChild(button);
        container.appendChild(this.spinner);
        // Append the icon and container to the widget's DOM node
        this.node.appendChild(iconImg);
        this.node.appendChild(container);
    }
    /**
     * Callback on click on the widget
     */
    async _onButtonClick(event) {
        console.log('JupyterLab extension ndp-jupyterlab-extension is activated!');
        this.spinner.style.display = 'block'; // Show spinner
        // Get the current path from the file manager
        // const currentPath = this.fileBrowser.model.path;
        console.log(`Current path: ${this.fileBrowser}`);
        console.log('Making request to JupyterLab API');
        try {
            const data = await (0,_handler__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('get-example', {
                method: 'GET',
                body: JSON.stringify({ path: this.fileBrowser })
            });
            console.log(data);
            window.alert('Datasets successfully downloaded');
        }
        catch (reason) {
            console.error(`The ndp_jupyterlab_extension server extension appears to be missing.\n${reason}`);
        }
        finally {
            this.spinner.style.display = 'none'; // Hide spinner
        }
    }
}
// Add CSS styles to center the button and style the icon and spinner
const style = document.createElement('style');
style.textContent = `
  .button-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
  }
  .my-button {
    padding: 10px 20px;
    font-size: 16px;
    margin-bottom: 20px;
  }
  .my-widget-icon {
    display: block;
    margin: 0 auto;
    width: 170px; /* Adjust the size as needed */
    height: 90px; /* Adjust the size as needed */
    padding-top: 10px;
  }
  .spinner {
    border: 4px solid rgba(0, 0, 0, 0.1);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border-left-color: #09f;
    animation: spin 1s ease infinite;
  }
  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;
document.head.appendChild(style);


/***/ }),

/***/ "./style/ndp_logo.png":
/*!****************************!*\
  !*** ./style/ndp_logo.png ***!
  \****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "75ca306c12e316e98388.png";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.6e20a98b0733c75364b9.js.map